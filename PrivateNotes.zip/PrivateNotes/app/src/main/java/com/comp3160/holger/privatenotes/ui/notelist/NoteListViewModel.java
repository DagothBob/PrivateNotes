package com.comp3160.holger.privatenotes.ui.notelist;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import java.util.List;

public class NoteListViewModel extends AndroidViewModel {
    
    private List list;
    
    public NoteListViewModel(@NonNull Application application) {
        super(application);
    }
    // TODO: Implement the ViewModel
}
